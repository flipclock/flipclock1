# FlipClock.io - Digital Flip Clock

A simple real-time digital flip clock built using HTML, CSS, and JavaScript.

⏱ Live Clock Preview: https://yourusername.github.io/flipclock

🌐 Visit the official website: [https://flipclock.io](https://flipclock.io)